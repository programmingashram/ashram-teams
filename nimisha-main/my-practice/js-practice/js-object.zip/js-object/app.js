var body = document.getElementById('body');

function section(){
    var container = document.createElement('div');
    body.appendChild(container);
    container.setAttribute('class', 'container');

    function box(){
        var row = document.createElement('div');
        container.appendChild(row);
        row.setAttribute('class', 'row');

        function col(){
            var item = document.createElement('div');
            row.appendChild(item);
            item.setAttribute('class', 'item');
        }col()

    }box()

}section()

let itemDetails = {
    AsusRyzen :{
        name : "ASUS Vivobook Pro 15 Ryzen 7 Octa Core AMD R7-4800H",
        review : 4.5 (632),
        price : $880
    },

    Asusoled :{
        name : "ASUS Vivobook Pro 15 OLED Ryzen 7 Octa Core AMD R7-4800H",
        review : 4.6 (489),
        price : $880
    },

    Asushexa :{
        name : "ASUS Vivobook Pro 15 Ryzen 7 Octa Core AMD R7-4800H",
        review : 4.5 (632),
        price : $880
    },

    MSIcore :{
        name : "ASUS Vivobook Pro 15 Ryzen 7 Octa Core AMD R7-4800H",
        review : 4.5 (632),
        price : $880
    },

    Acer :{
        name : "ASUS Vivobook Pro 15 Ryzen 7 Octa Core AMD R7-4800H",
        review : 4.5 (632),
        price : $880
    }
}